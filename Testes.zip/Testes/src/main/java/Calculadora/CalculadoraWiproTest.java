package Calculadora;
import org.junit.Assert;
import org.junit.Test;


public class CalculadoraWiproTest {
	
	@Test
	public void somarDoisNumeros() {
		
		CalculadoraWipro calc = new CalculadoraWipro();
		int soma = calc.somar(2, 2); 	
		
		Assert.assertEquals(4, soma);
		

	}

}
