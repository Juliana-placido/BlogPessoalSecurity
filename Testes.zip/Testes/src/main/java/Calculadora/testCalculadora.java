package Calculadora;

public class testCalculadora {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CalculadoraWipro calc = new CalculadoraWipro();
		int soma = calc.somar(2, 2);
		System.out.println(soma);
		
		soma = calc.somar(3, 2);
		System.out.println(soma);
		
		soma = calc.somar(4, 2);
		System.out.println(soma);
	}

}
