package Calculadora;

public class CalculadoraWipro {

	public int somar(int a, int b) {
		return a+b;
	}

}
