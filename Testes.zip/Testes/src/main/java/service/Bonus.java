package service;

import java.math.BigDecimal;

import model.Funcionario;


public class Bonus {

	public BigDecimal calcularBonus (Funcionario funcionario) {
		BigDecimal valor = funcionario.getSalario().multiply(new BigDecimal("0.2"));
		if (valor.compareTo(new BigDecimal ("1000")) >0) {
			valor = BigDecimal.ZERO;
		}
		 return valor;	
	}
}
