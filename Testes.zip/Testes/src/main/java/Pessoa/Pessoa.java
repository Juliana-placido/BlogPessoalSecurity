package Pessoa;

public class Pessoa {

	public  void verificarIdade(int x) {
		
		if (x >= 60) {
			String pessoa = "Senhor";
			System.out.println(pessoa);
		}else if(x >=18) {
			String pessoa = "Adulto";
			System.out.println(pessoa);
		} else {
			String pessoa = "Crian�a";
			System.out.println(pessoa);
		}

	}

}
