package service;

import static org.junit.Assert.*;

import java.math.BigDecimal;
import java.time.LocalDate;

import org.junit.Test;

import model.Funcionario;

public class BonusTest {

	  @Test
	    void bonusZeroParaSalarioAlto() {
	        Bonus service = new Bonus();
	            service.calcularBonus (new Funcionario("Rodrigo", LocalDate.now(), new BigDecimal("25000")));

	        }

	}


