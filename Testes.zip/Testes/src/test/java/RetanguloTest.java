import static org.junit.Assert.*;

import org.junit.Test;

public class RetanguloTest {

	@Test
	public void testCalcularArea() {
		Retangulo retangulo = new Retangulo();
		int a = 10;
		int b = 2;
		int resultadoEsperado = 20;
		
		int resultado = retangulo.calcularArea(a,b);
		
		assertEquals(resultadoEsperado, resultado);
	}

}
