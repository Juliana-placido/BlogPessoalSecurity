
public class Retangulo {


	public int calcularArea(int a, int b) {
		return a*b;
	}

}
