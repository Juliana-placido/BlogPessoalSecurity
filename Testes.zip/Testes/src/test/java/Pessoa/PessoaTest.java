package Pessoa;

import static org.junit.Assert.*;

import org.junit.Test;

public class PessoaTest {

	@Test
	public void testVerificarIdade() {
		Pessoa pessoa = new Pessoa();
		pessoa.verificarIdade(61);
		assertTrue(true);
			}
	@Test
	public void testVerificarIdadeJovem() {
		Pessoa pessoa = new Pessoa();
		pessoa.verificarIdade(18);
		assertTrue(true);
			}
	@Test
	public void testVerificarIdadeCrian�a() {
		Pessoa pessoa = new Pessoa();
		pessoa.verificarIdade(10);
		assertTrue(true);
			}
}
